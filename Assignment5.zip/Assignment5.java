package co.edurekatraining;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class Assignment5 {
	
	String hubUrl ="http://192.168.1.153:4444";
	String url ="https://www.rediff.com";
	WebDriver driver ;

	public static void main(String[] args) {
		Assignment5 obj = new Assignment5();
		obj.setupGrid();
		obj.pageTitleValidation();

	}

	public void setupGrid()
	{
	DesiredCapabilities ds= new DesiredCapabilities();
	ds.setCapability("browserName", "chrome");
	//ds.setCapability("browserName", "firefox");
	try {
	driver = new RemoteWebDriver( new URL(hubUrl),ds);
	} catch (MalformedURLException e) {
		e.printStackTrace();
		}
		driver.get(url);
		}

	public void pageTitleValidation() {
		driver.manage().window().maximize();
		String title = driver.getTitle();
		System.out.println("page title :" +title);
		}

	
}
